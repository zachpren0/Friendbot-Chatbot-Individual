package freindbot;

import java.io.IOException;
import java.math.BigDecimal;

import yahoofinance.Stock;
import yahoofinance.YahooFinance;

public class yahooFinance {

	public static void main(String [] a) throws IOException {
	
	Stock stock = YahooFinance.get("amzn");
	 
	BigDecimal price = stock.getQuote().getPrice();
	BigDecimal change = stock.getQuote().getChangeInPercent();
	BigDecimal peg = stock.getStats().getPeg();
	BigDecimal dividend = stock.getDividend().getAnnualYieldPercent();
	
	//System.out.println(stock.toString());
	//System.out.println(price);
	System.out.println(getPrice("amzn"));
	 
	}
	public static String getPrice(String ticker) throws IOException {
		
		
		
		Stock stock = YahooFinance.get(ticker);
		BigDecimal price = stock.getQuote().getPrice();
		
		String result = price.toString();
		
		
		
		return result;
	}
	
	
}
