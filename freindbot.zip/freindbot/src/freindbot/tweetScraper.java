package freindbot;

import java.util.*;
import twitter4j.*;
import twitter4j.conf.*;

public class tweetScraper {

static String user = null;

	public static void main(String[] a) {
	    
	    
	    System.out.println(getLastTweet("pigeonglock"));
	    
	    
	   
	}
	public static String getLastTweet(String user) {
		try {
			
		
		ConfigurationBuilder cb = new ConfigurationBuilder();
		cb.setOAuthConsumerKey("YOUR KEY HERE");
	    cb.setOAuthConsumerSecret("YOUR KEY HERE");
	    cb.setOAuthAccessToken("YOUR KEY HERE");
	    cb.setOAuthAccessTokenSecret("YOUR KEY HERE");
		
		String result = null;
		int pageno = 1;
	    List statuses = new ArrayList();
	    Twitter twitter = new TwitterFactory(cb.build()).getInstance();
	    try {
	    while (true) {

	     // try {

	        int size = statuses.size(); 
	        Paging page = new Paging(pageno++, 100);
	        statuses.addAll(twitter.getUserTimeline(user, page));
	        
	        
	        
	        
	     
	        
	       
	        
	        if (statuses.size() == size)
	          break;
	     // }
	     // catch(TwitterException e) {

	      //  e.printStackTrace();
	      }
	    }
	    catch(TwitterException e) {

	        e.printStackTrace();
	      }
	    String s = statuses.get(0).toString();
	    String [] arr = s.split(",");
	   
	    
	    for (int i = 0; i < arr.length; i++) {
	     //System.out.println(arr[i]);
			if (arr[i].contains("text")) {
		//System.out.println(arr[i]); 
			result = arr[i];
			String [] arr2 = arr[i].split("'");
			//System.out.println(arr2[1]);
			result = arr2[1];
			break;
			}	
		}
		
		
		return result;
		}
		catch (Exception e){
			
		return "I am unable to get the tweet, please ensure the username begins with @ and the account is public.";
			
		}
		
	}
}

